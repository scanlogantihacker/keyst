package vn.dcks;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Mot theme = 1 file .json trong config/dckeystrokes/themes/. Mau dang #AARRGGBB hoac #RRGGBB. */
public class Theme {
    public String bg = "#73000000";
    public String bgPressed = "#E6FFFFFF";
    public String text = "#FFFFFFFF";
    public String textPressed = "#FF111111";
    public String border = "#00000000";
    public String borderPressed = "#00000000";
    public boolean rounded = true;
    public String glow = "#00000000";
    public int glowSize = 3;
    public int fadeInMs = 150;
    public int fadeOutMs = 220;
    public float strength = 1f;

    public transient int cBg, cBgP, cTx, cTxP, cBd, cBdP, cGlow;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Map<String, Theme> ALL = new LinkedHashMap<>();

    private static Path dir() {
        return FabricLoader.getInstance().getConfigDir().resolve("dckeystrokes").resolve("themes");
    }

    private void bake() {
        cBg = parse(bg, 0x73000000);
        cBgP = parse(bgPressed, 0xE6FFFFFF);
        cTx = parse(text, 0xFFFFFFFF);
        cTxP = parse(textPressed, 0xFF111111);
        cBd = parse(border, 0);
        cBdP = parse(borderPressed, 0);
        cGlow = parse(glow, 0);
    }

    static int parse(String s, int def) {
        try {
            String h = s.startsWith("#") ? s.substring(1) : s;
            long v = Long.parseLong(h, 16);
            if (h.length() <= 6) v |= 0xFF000000L;
            return (int) v;
        } catch (Exception e) {
            return def;
        }
    }

    private static Theme mk(boolean r, String bg, String bgP, String tx, String txP, String bd, String bdP) {
        Theme t = new Theme();
        t.rounded = r;
        t.bg = bg;
        t.bgPressed = bgP;
        t.text = tx;
        t.textPressed = txP;
        t.border = bd;
        t.borderPressed = bdP;
        return t;
    }

    private static void write(String name, Theme t) throws IOException {
        Path f = dir().resolve(name + ".json");
        if (Files.exists(f)) return;
        try (Writer w = Files.newBufferedWriter(f)) {
            GSON.toJson(t, w);
        }
    }

    private static void writeDefaults() throws IOException {
        Theme dawn = mk(true, "#40FFFFFF", "#FFFFD93D", "#FFFFFFFF", "#FF3A2A00", "#33FFFFFF", "#FFFFF1A8");
        dawn.glow = "#FFD93D";
        dawn.glowSize = 4;
        dawn.fadeInMs = 280;
        dawn.fadeOutMs = 420;
        dawn.strength = 0.9f;
        write("dawn", dawn);
        write("medal", mk(true, "#73000000", "#E6FFFFFF", "#FFFFFFFF", "#FF111111", "#00000000", "#00000000"));
        write("neon", mk(true, "#99101018", "#FF00E5FF", "#FFB8F4FF", "#FF001014", "#6600E5FF", "#FFFFFFFF"));
        write("sakura", mk(true, "#80301020", "#FFFF7EB6", "#FFFFD6E8", "#FF3A0A1E", "#55FF7EB6", "#FFFFFFFF"));
        write("blood", mk(true, "#80200000", "#FFFF2A2A", "#FFFFC9C9", "#FF1A0000", "#44FF2A2A", "#FFFFFFFF"));
        write("classic", mk(false, "#99000000", "#99FFFFFF", "#FFFFFFFF", "#FF000000", "#00000000", "#00000000"));
    }

    public static void loadAll() {
        ALL.clear();
        try {
            Path d = dir();
            Files.createDirectories(d);
            writeDefaults();
            try (var s = Files.list(d)) {
                s.filter(p -> p.toString().endsWith(".json")).sorted().forEach(p -> {
                    try (Reader r = Files.newBufferedReader(p)) {
                        Theme t = GSON.fromJson(r, Theme.class);
                        if (t != null) {
                            t.bake();
                            String n = p.getFileName().toString();
                            ALL.put(n.substring(0, n.length() - 5).toLowerCase(), t);
                        }
                    } catch (Exception e) {
                        System.err.println("[dckeystrokes] loi theme " + p + ": " + e);
                    }
                });
            }
        } catch (IOException e) {
            System.err.println("[dckeystrokes] loi doc themes: " + e);
        }
        if (ALL.isEmpty()) {
            Theme t = new Theme();
            t.bake();
            ALL.put("medal", t);
        }
    }

    public static Theme current() {
        Theme t = ALL.get(Config.get().theme);
        return t != null ? t : ALL.values().iterator().next();
    }

    public static List<String> names() {
        return new ArrayList<>(ALL.keySet());
    }

    public static boolean has(String n) {
        return ALL.containsKey(n);
    }

    public static String cycle() {
        List<String> n = names();
        int i = n.indexOf(Config.get().theme);
        String next = n.get((i + 1) % n.size());
        Config.get().theme = next;
        Config.save();
        return next;
    }
}
