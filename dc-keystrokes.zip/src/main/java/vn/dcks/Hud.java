package vn.dcks;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.render.RenderTickCounter;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;

public final class Hud {
    private static final Map<String, Float> ANIM = new HashMap<>();
    private static final ArrayDeque<Long> LMB = new ArrayDeque<>();
    private static final ArrayDeque<Long> RMB = new ArrayDeque<>();
    private static boolean lPrev, rPrev, lDown, rDown;
    private static long lastNs = System.nanoTime();
    private static int prevHurt;

    public static int combo;
    private static long lastHitMs;

    private Hud() {}

    public static void onHit() {
        combo++;
        lastHitMs = System.currentTimeMillis();
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null) {
            combo = 0;
            prevHurt = 0;
            return;
        }
        if (mc.player.hurtTime > prevHurt) combo = 0;
        prevHurt = mc.player.hurtTime;
        if (combo > 0 && System.currentTimeMillis() - lastHitMs > 4000) combo = 0;
    }

    private static void pollMouse(MinecraftClient mc, long now) {
        boolean free = mc.currentScreen == null;
        long w = mc.getWindow().getHandle();
        lDown = free && GLFW.glfwGetMouseButton(w, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        rDown = free && GLFW.glfwGetMouseButton(w, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (lDown && !lPrev) LMB.addLast(now);
        if (rDown && !rPrev) RMB.addLast(now);
        lPrev = lDown;
        rPrev = rDown;
    }

    private static int cps(ArrayDeque<Long> q, long now) {
        while (!q.isEmpty() && now - q.peekFirst() > 1000) q.pollFirst();
        return q.size();
    }

    private static float anim(String id, boolean down, float dt, Theme t) {
        float r = ANIM.getOrDefault(id, 0f);
        float dur = Math.max(0.02f, (down ? t.fadeInMs : t.fadeOutMs) / 1000f);
        r += (down ? 1f : -1f) * dt / dur;
        r = Math.max(0f, Math.min(1f, r));
        ANIM.put(id, r);
        float e = r * r * (3f - 2f * r);
        return e * Math.max(0f, Math.min(1f, t.strength));
    }

    private static void glow(DrawContext c, Theme t, int x, int y, int w, int h, float p) {
        int a0 = t.cGlow >>> 24;
        if (a0 == 0 || p <= 0.01f) return;
        for (int i = 1; i <= t.glowSize; i++) {
            int a = Math.round(a0 * p * 0.5f / i);
            if (a <= 0) break;
            shape(c, t, x - i, y - i, w + 2 * i, h + 2 * i, (a << 24) | (t.cGlow & 0xFFFFFF));
        }
    }

    static int lerp(int a, int b, float p) {
        int r = 0;
        for (int sh = 0; sh < 32; sh += 8) {
            int ca = (a >>> sh) & 255;
            int cb = (b >>> sh) & 255;
            r |= (Math.round(ca + (cb - ca) * p) & 255) << sh;
        }
        return r;
    }

    private static void shape(DrawContext c, Theme t, int x, int y, int w, int h, int col) {
        if (t.rounded && w > 4 && h > 4) {
            c.fill(x + 1, y, x + w - 1, y + h, col);
            c.fill(x, y + 1, x + 1, y + h - 1, col);
            c.fill(x + w - 1, y + 1, x + w, y + h - 1, col);
        } else {
            c.fill(x, y, x + w, y + h, col);
        }
    }

    private static void panel(DrawContext c, Theme t, int x, int y, int w, int h, int bg, int bd) {
        shape(c, t, x, y, w, h, bg);
        if ((bd >>> 24) > 0) {
            int o = t.rounded ? 1 : 0;
            c.fill(x + o, y, x + w - o, y + 1, bd);
            c.fill(x + o, y + h - 1, x + w - o, y + h, bd);
            c.fill(x, y + o, x + 1, y + h - o, bd);
            c.fill(x + w - 1, y + o, x + w, y + h - o, bd);
        }
    }

    private static void key(DrawContext c, TextRenderer tr, Theme t, String id, String label,
                            boolean down, int x, int y, int w, int h, float dt) {
        float p = anim(id, down, dt, t);
        glow(c, t, x, y, w, h, p);
        panel(c, t, x, y, w, h, lerp(t.cBg, t.cBgP, p), lerp(t.cBd, t.cBdP, p));
        int fg = lerp(t.cTx, t.cTxP, p);
        if (label.isEmpty()) {
            c.fill(x + w / 4, y + h / 2, x + w - w / 4, y + h / 2 + 1, fg);
        } else {
            c.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2 + 1, fg, false);
        }
    }

    private static void mouse(DrawContext c, TextRenderer tr, Theme t, String id, String label, int cps,
                              boolean showCps, boolean down, int x, int y, int w, int h, float dt) {
        float p = anim(id, down, dt, t);
        glow(c, t, x, y, w, h, p);
        panel(c, t, x, y, w, h, lerp(t.cBg, t.cBgP, p), lerp(t.cBd, t.cBdP, p));
        int fg = lerp(t.cTx, t.cTxP, p);
        if (!showCps) {
            c.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2 + 1, fg, false);
            return;
        }
        int y1 = y + (h - 17) / 2 + 1;
        c.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y1, fg, false);
        String s = cps + " CPS";
        int dim = (fg & 0x00FFFFFF) | 0xAA000000;
        c.drawText(tr, s, x + (w - tr.getWidth(s)) / 2, y1 + 9, dim, false);
    }

    private static void stat(DrawContext c, TextRenderer tr, Theme t, String s, int x, int y, int w, int h) {
        panel(c, t, x, y, w, h, t.cBg, t.cBd);
        c.drawText(tr, s, x + (w - tr.getWidth(s)) / 2, y + (h - 8) / 2 + 1, t.cTx, false);
    }

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Config cfg = Config.get();
        if (mc.player == null || mc.options.hudHidden || !cfg.enabled) return;

        long now = System.currentTimeMillis();
        pollMouse(mc, now);

        long ns = System.nanoTime();
        float dt = Math.min((ns - lastNs) / 1_000_000_000f, 0.1f);
        lastNs = ns;

        Theme t = Theme.current();
        TextRenderer tr = mc.textRenderer;
        GameOptions o = mc.options;

        int s = Math.max(16, Math.min(48, cfg.size));
        int g = 2;
        int x0 = cfg.x;
        int y = cfg.y;
        int full = s * 3 + g * 2;

        key(ctx, tr, t, "w", "W", o.forwardKey.isPressed(), x0 + s + g, y, s, s, dt);
        y += s + g;
        key(ctx, tr, t, "a", "A", o.leftKey.isPressed(), x0, y, s, s, dt);
        key(ctx, tr, t, "s", "S", o.backKey.isPressed(), x0 + s + g, y, s, s, dt);
        key(ctx, tr, t, "d", "D", o.rightKey.isPressed(), x0 + 2 * (s + g), y, s, s, dt);
        y += s + g;

        if (cfg.showMouse) {
            int w1 = (full - g) / 2;
            int w2 = full - g - w1;
            mouse(ctx, tr, t, "lmb", "LMB", cps(LMB, now), cfg.showCps, lDown, x0, y, w1, s, dt);
            mouse(ctx, tr, t, "rmb", "RMB", cps(RMB, now), cfg.showCps, rDown, x0 + w1 + g, y, w2, s, dt);
            y += s + g;
        }

        int sh = s * 2 / 3;
        if (cfg.showSpace) {
            key(ctx, tr, t, "space", "", o.jumpKey.isPressed(), x0, y, full, sh, dt);
            y += sh + g;
        }
        if (cfg.showShift) {
            int w1 = (full - g) / 2;
            int w2 = full - g - w1;
            key(ctx, tr, t, "shift", "SHIFT", o.sneakKey.isPressed(), x0, y, w1, sh, dt);
            key(ctx, tr, t, "sprint", "SPRINT", o.sprintKey.isPressed(), x0 + w1 + g, y, w2, sh, dt);
            y += sh + g;
        }

        if (cfg.showStats) {
            int h = 14;
            if (cfg.showFps) {
                stat(ctx, tr, t, "FPS " + mc.getCurrentFps(), x0, y, full, h);
                y += h + g;
            }
            if (cfg.showPing) {
                ClientPlayNetworkHandler nh = mc.getNetworkHandler();
                PlayerListEntry e = nh == null ? null : nh.getPlayerListEntry(mc.player.getUuid());
                if (e != null) {
                    stat(ctx, tr, t, "PING " + e.getLatency() + " ms", x0, y, full, h);
                    y += h + g;
                }
            }
            if (cfg.showCombo) {
                stat(ctx, tr, t, "COMBO " + combo, x0, y, full, h);
            }
        }
    }
}
