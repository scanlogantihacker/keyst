package vn.dcks.mixin;

import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import vn.dcks.Config;

@Mixin(InGameOverlayRenderer.class)
public class FireOverlayMixin {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"))
    private static void dcks$lowFire(MatrixStack matrices, VertexConsumerProvider vertexConsumers, CallbackInfo ci) {
        Config c = Config.get();
        if (c.lowFire) {
            matrices.translate(0.0f, -c.fireOffset, 0.0f);
        }
    }
}
