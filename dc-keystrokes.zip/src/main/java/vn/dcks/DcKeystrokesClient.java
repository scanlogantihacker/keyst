package vn.dcks;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.command.CommandSource;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class DcKeystrokesClient implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static KeyBinding themeKey;
    private static KeyBinding zoomKey;
    private static boolean zooming;
    private static int savedFov;

    @Override
    public void onInitializeClient() {
        Config.load();
        Theme.loadAll();

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.dckeystrokes.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, KeyBinding.Category.MISC));
        themeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.dckeystrokes.theme", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_CONTROL, KeyBinding.Category.MISC));

        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.dckeystrokes.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, KeyBinding.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (toggleKey.wasPressed()) {
                Config.get().enabled = !Config.get().enabled;
                Config.save();
            }
            while (themeKey.wasPressed()) {
                String n = Theme.cycle();
                if (mc.player != null) mc.player.sendMessage(Text.literal("§7[KS] Theme: §f" + n), true);
            }
            tickZoom(mc);
            Hud.tick(mc);
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient() && entity instanceof LivingEntity
                    && player == MinecraftClient.getInstance().player) {
                Hud.onHit();
            }
            return ActionResult.PASS;
        });

        HudElementRegistry.attachElementAfter(
                VanillaHudElements.MISC_OVERLAYS, Identifier.of("dckeystrokes", "keystrokes"), Hud::render);

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> registerCommands(dispatcher));
    }

    private static void tickZoom(MinecraftClient mc) {
        var opt = mc.options.getFov();
        boolean want = zoomKey.isPressed() && mc.currentScreen == null;
        if (want) {
            if (!zooming) {
                savedFov = opt.getValue();
                zooming = true;
            }
            int target = Math.max(30, Math.min(90, Config.get().zoomFov));
            int cur = opt.getValue();
            if (cur > target) opt.setValue(Math.max(target, cur - 8));
            else if (cur < target) opt.setValue(Math.min(target, cur + 8));
        } else if (zooming) {
            int cur = opt.getValue();
            if (cur < savedFov) {
                opt.setValue(Math.min(savedFov, cur + 8));
            } else {
                opt.setValue(savedFov);
                zooming = false;
            }
        }
    }

    private static void msg(CommandContext<FabricClientCommandSource> c, String s) {
        c.getSource().sendFeedback(Text.literal(s));
    }

    private static boolean flip(Config c, String k) {
        switch (k) {
            case "mouse": return c.showMouse = !c.showMouse;
            case "cps": return c.showCps = !c.showCps;
            case "space": return c.showSpace = !c.showSpace;
            case "shift": return c.showShift = !c.showShift;
            case "stats": return c.showStats = !c.showStats;
            case "fps": return c.showFps = !c.showFps;
            case "ping": return c.showPing = !c.showPing;
            default: return c.showCombo = !c.showCombo;
        }
    }

    private static void registerCommands(CommandDispatcher<FabricClientCommandSource> d) {
        var root = ClientCommandManager.literal("ks");
        root.executes(c -> {
            msg(c, "§e/ks toggle | theme <ten> | themes | reload | pos <x> <y> | size <16-48> | show <mouse|cps|space|shift|stats|fps|ping|combo> | lowfire [0-100] | zoom <30-90>");
            return 1;
        });

        root.then(ClientCommandManager.literal("toggle").executes(c -> {
            Config.get().enabled = !Config.get().enabled;
            Config.save();
            msg(c, Config.get().enabled ? "§aBat Keystrokes" : "§cTat Keystrokes");
            return 1;
        }));

        root.then(ClientCommandManager.literal("themes").executes(c -> {
            msg(c, "§eTheme: §f" + String.join(", ", Theme.names()));
            return 1;
        }));

        root.then(ClientCommandManager.literal("reload").executes(c -> {
            Config.load();
            Theme.loadAll();
            msg(c, "§aDa nap lai config + theme (" + Theme.names().size() + " theme)");
            return 1;
        }));

        root.then(ClientCommandManager.literal("theme")
                .then(ClientCommandManager.argument("name", StringArgumentType.word())
                        .suggests((c, b) -> CommandSource.suggestMatching(Theme.names(), b))
                        .executes(c -> {
                            String n = StringArgumentType.getString(c, "name").toLowerCase();
                            if (!Theme.has(n)) {
                                msg(c, "§cKhong co theme '" + n + "'. Dung /ks themes");
                                return 0;
                            }
                            Config.get().theme = n;
                            Config.save();
                            msg(c, "§aTheme: " + n);
                            return 1;
                        })));

        root.then(ClientCommandManager.literal("pos")
                .then(ClientCommandManager.argument("x", IntegerArgumentType.integer(0, 4000))
                        .then(ClientCommandManager.argument("y", IntegerArgumentType.integer(0, 4000))
                                .executes(c -> {
                                    Config.get().x = IntegerArgumentType.getInteger(c, "x");
                                    Config.get().y = IntegerArgumentType.getInteger(c, "y");
                                    Config.save();
                                    msg(c, "§aVi tri: " + Config.get().x + ", " + Config.get().y);
                                    return 1;
                                }))));

        root.then(ClientCommandManager.literal("size")
                .then(ClientCommandManager.argument("n", IntegerArgumentType.integer(16, 48))
                        .executes(c -> {
                            Config.get().size = IntegerArgumentType.getInteger(c, "n");
                            Config.save();
                            msg(c, "§aKich thuoc phim: " + Config.get().size);
                            return 1;
                        })));

        var show = ClientCommandManager.literal("show");
        for (String k : new String[]{"mouse", "cps", "space", "shift", "stats", "fps", "ping", "combo"}) {
            show.then(ClientCommandManager.literal(k).executes(c -> {
                boolean on = flip(Config.get(), k);
                Config.save();
                msg(c, "§7" + k + ": " + (on ? "§abat" : "§ctat"));
                return 1;
            }));
        }
        root.then(show);

        root.then(ClientCommandManager.literal("lowfire")
                .executes(c -> {
                    Config.get().lowFire = !Config.get().lowFire;
                    Config.save();
                    msg(c, "§7Low Fire: " + (Config.get().lowFire ? "§abat" : "§ctat"));
                    return 1;
                })
                .then(ClientCommandManager.argument("percent", IntegerArgumentType.integer(0, 100))
                        .executes(c -> {
                            int n = IntegerArgumentType.getInteger(c, "percent");
                            Config.get().fireOffset = n / 100f;
                            Config.get().lowFire = true;
                            Config.save();
                            msg(c, "§aLow Fire ha thap: " + n + "%");
                            return 1;
                        })));

        root.then(ClientCommandManager.literal("zoom")
                .then(ClientCommandManager.argument("fov", IntegerArgumentType.integer(30, 90))
                        .executes(c -> {
                            Config.get().zoomFov = IntegerArgumentType.getInteger(c, "fov");
                            Config.save();
                            msg(c, "§aZoom FOV: " + Config.get().zoomFov);
                            return 1;
                        })));

        d.register(root);
    }
}
