package vn.dcks;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public class Config {
    public boolean enabled = true;
    public boolean showMouse = true;
    public boolean showCps = true;
    public boolean showSpace = true;
    public boolean showShift = true;
    public boolean showStats = true;
    public boolean showFps = true;
    public boolean showPing = true;
    public boolean showCombo = true;
    public int x = 8;
    public int y = 8;
    public int size = 26;
    public String theme = "dawn";
    public boolean lowFire = true;
    public float fireOffset = 0.3f;
    public int zoomFov = 30;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Config inst = new Config();

    public static Config get() {
        return inst;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("dckeystrokes").resolve("config.json");
    }

    public static void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                try (Reader r = Files.newBufferedReader(f)) {
                    Config c = GSON.fromJson(r, Config.class);
                    if (c != null) inst = c;
                }
            } else {
                save();
            }
        } catch (Exception e) {
            System.err.println("[dckeystrokes] loi doc config: " + e);
        }
    }

    public static void save() {
        try {
            Path f = file();
            Files.createDirectories(f.getParent());
            try (Writer w = Files.newBufferedWriter(f)) {
                GSON.toJson(inst, w);
            }
        } catch (Exception e) {
            System.err.println("[dckeystrokes] loi luu config: " + e);
        }
    }
}
